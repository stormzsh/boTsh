import random

from settings import *

def getSlotsScreen():
	slots = ['chocolate_bar', 'bell', 'tangerine', 'apple', 'cherries', 'seven']
	slot1 = slots[random.randint(0, 5)]
	slot2 = slots[random.randint(0, 5)]
	slot3 = slots[random.randint(0, 5)]
	slot4 = slots[random.randint(0, 5)]

	slotOutput = '|\t:{}:\t|\t:{}:\t|\t:{}:\t|\t:{}:\t|\n'.format(slot1, slot2, slot3, slot4)


	if slot1 == slot2 and slot2 == slot3 and slot3 == slot4 and slot4 != 'seven':
		return slotOutput + '$$ GREAT $$'

	elif slot1 == 'seven' and slot2 == 'seven' and slot3 == 'seven' and slot4 == 'seven':
		return slotOutput + '$$ JACKPOT $$'

	elif slot1 == slot2 and slot3 == slot4 or slot1 == slot3 and slot2 == slot4 or slot1 == slot4 and slot2 == slot3:
		return slotOutput + '$ NICE $'

	else:
            return slotOutput