import discord
from discord.ext import commands
import asyncio
import TOKEN
import random
import requests
import io
import safygiphy
from features import rng
from settings import config

client = discord.Client()
client = commands.Bot(command_prefix="?")
stormshssid = "392288988519464960"
g = safygiphy.Giphy()
testmsgid = None
testmsguser = None


minutes = 0
hour = 0
day = 0
week = 0

@client.event
async def on_ready():
    print('Logged as:')
    print(client.user.name)
    print(client.user.id)
    print("-------------\n")
    await client.change_presence(game=discord.Game(name="autism"))


@client.event
async def on_message(message):
    if message.content.lower().startswith('?test'):
        await client.send_message(message.channel, "Test")

    if message.content.lower().startswith('?coin'):
        choice = random.randint(1,2)
        if choice == 1:
            await client.add_reaction(message, "🌑")
        if choice == 2:
            await client.add_reaction(message, "🌕")

    if message.content.lower().startswith("?game") and message.author.id == stormshssid:
        game = message.content[6:]
        await client.change_presence(game=discord.Game(name=game))
        await client.send_message(message.channel, "My status is now on: " + game + ".")

    if message.content.startswith("?catgif"):
        response = requests.get("http://i0.kym-cdn.com/photos/images/newsfeed/000/805/621/cd9.gif", stream=True)
        await client.send_file(message.channel, io.BytesIO(response.raw.read()), filename='bild.gif', content="")

    if message.content.startswith("?uptime"):
        await client.send_message(message.channel, "Bot is up from {0} weeks, {1} days, {2}, hours and {3} minutes.".format(week, day, hour, minutes) )

    if message.content.startswith("?clear "):
        clear = message.content
        num = int(clear[6:])
        await client.purge_from(message.channel, limit=num)
        await client.send_message(message.channel, "{} messages removed.".format(num))

    if message.content.startswith("?gif"):
        gif_tag = message.content[5:]
        rgif= g.random(tag=str(gif_tag))
        response = requests.get(
            str(rgif.get("data", {}).get("image_original_url")), stream=True
        )
        await client.send_file(message.channel, io.BytesIO(response.raw.read()), filename="gif.gif")

    if message.content.lower().startswith("?user"):
        try:
            user = message.mentions[0]
            userjoinedat = str(user.joined_at).split('.', 1)[0]
            usercreatedat = str(user.created_at).split('.', 1)[0]

            userembed = discord.Embed(
                title="Username:",
                description=user.name,
                color=0xe67e22
            )
            userembed.set_author(
                name="User info"
            )
            userembed.add_field(
                name="Joined the server at:",
                value=userjoinedat
            )
            userembed.add_field(
                name="User Created at:",
                value=usercreatedat
            )
            userembed.add_field(
                name="Discriminator",
                value=user.discriminator
            )
            userembed.add_field(
                name="User ID;",
                value=user.id
            )
            userembed.set_thumbnail(url=user.avatar_url)

            await client.send_message(message.channel, embed=userembed)
        except IndexError:
            await client.send_message(message.channel, "I can't find this user!")
        except:
            await client.send_message(message.channel, "Sorry, an error occurred while checking this user!")
        finally:
            pass

    if message.content.startswith("?kick "):
        usernamenick = message.mentions[0]
        await client.kick(usernamenick)
        await client.send_message(message.channel, "{} just got kicked!".format(usernamenick))

    if message.content.startswith("?ban"):
        usernamenick = message.mentions[0]
        await client.ban(usernamenick)
        await client.send_message(message.channel, "{} just got banned!".format(usernamenick))

    if message.content.lower().startswith("?color green"):
        msg = message.content
        chat = message.channel
        usercol = message.author
        role = discord.utils.find(lambda r: r.name == "green", chat.server.roles)
        await client.add_roles(usercol, role)
        await client.send_message(chat, "Your color is now green!")
        print(usercol, " just changed his color to green!")

    if message.content.lower().startswith("?color blue"):
        msg = message.content
        chat = message.channel
        usercol = message.author
        role = discord.utils.find(lambda r: r.name == "blue", chat.server.roles)
        await client.add_roles(usercol, role)
        await client.send_message(chat, "Your color is now blue!")
        print(usercol, " just changed his color to blue!")

    if message.content.lower().startswith("?color yellow"):
        msg = message.content
        chat = message.channel
        usercol = message.author
        role = discord.utils.find(lambda r: r.name == "yellow", chat.server.roles)
        await client.add_roles(usercol, role)
        await client.send_message(chat, "Your color is now yellow!")
        print(usercol, " just changed his color to yellow!")

    if message.content.lower().startswith("?color black"):
        msg = message.content
        chat = message.channel
        usercol = message.author
        role = discord.utils.find(lambda r: r.name == "black", chat.server.roles)
        await client.add_roles(usercol, role)
        await client.send_message(chat, "Your color is now black!")
        print(usercol, " just changed his color to black!")

    if message.content.lower().startswith("?color red"):
        msg = message.content
        chat = message.channel
        usercol = message.author
        role = discord.utils.find(lambda r: r.name == "red", chat.server.roles)
        await client.add_roles(usercol, role)
        await client.send_message(chat, "Your color is now red!")
        print(usercol, " just changed his color to red!")

    if message.content.startswith("?slots"):
        await client.send_message(message.channel, rng.getSlotsScreen())

    if message.content.startswith("?shutdown") and message.author.id == stormshssid:
        await client.send_message(message.channel, "Shutting down. Bye!")
        await client.logout()
        await client.close()
        print(message.author, " just shut down the bot!")

    if message.content.startswith("?invite"):
        await client.send_message(message.channel, "Sending you a PM!")
        await client.send_message(message.author, 'Invite URL: ' + 'https://discordapp.com/oauth2/authorize?&client_id=' + client.user.id + '&scope=bot&permissions=0')

    if message.content.startswith("?mute"):
        userToMute = message.mentions[0]
        chat = message.channel
        muted = discord.utils.find(lambda r: r.name == "Muted", chat.server.roles)

        await client.add_roles(userToMute, muted)
        await client.send_message(message.channel, "{} has been muted!".format(userToMute))

async def tutorial_uptime():
    await client.wait_until_ready()
    global minutes
    minutes = 0
    global hour
    hour = 0
    global day
    day = 0
    global week
    week = 0
    while not client.is_closed:
        await asyncio.sleep(60)
        minutes += 1
        if minutes == 60:
            minutes = 0
            hour += 1
            if hour == 24:
                hour = 0
                day += 1
                if day == 1:
                    day = 0
                    week = 1

client.loop.create_task(tutorial_uptime())
client.run(TOKEN.TOKEN)